const sqlite = require('sqlite3');
const express = require('express');
var bodyParser = require('body-parser');
var path = require('path');
var urlencodedParser = bodyParser.urlencoded({
    extended: false
});

const hostname = '0.0.0.0';
const port = 90;


let db = new sqlite.Database("./database.sqlite3", (err) => {
    if (err) {
        console.log('ERREUR, ligne 13', err)
    } else {
        console.log('BDD OK')

        db.run(`CREATE TABLE IF NOT EXISTS todo(id INTEGER PRIMARY KEY AUTOINCREMENT,
                                                name VARCHAR(25),
                                                done INTEGER(1))`);
    }
});


var app = express();
app.use(express.static(path.join(__dirname, './')));
app.set('view engine', 'ejs');

app.get('/', function(req, res) {

    var todoList = [];
    const sql = "SELECT * FROM todo";
    db.all(sql, [], (err, rows) => {
        if (err) {
            throw err;
        }

        rows.forEach((row) => {
            todoList.push({
                'id': row.id,
                'name': row.name,
                'done': row.done
            });
        });

        res.render('pages/home', {
            data: todoList
        });
    });
});

app.get('/ajout', function(req, res) {
    res.render('pages/form');
});

app.get('/maj/:id', function(req, res) {

    var id = parseInt(req.params.id, 10);

    var todo = null;
    db.get("SELECT id, name, done FROM todo WHERE id = ?", [id], function(err, row) {
        if (err) {
            return console.log(err.message);
        }

        todo = row;
        if (todo) {

            db.run("UPDATE todo SET done = ? WHERE id = ?", [1, id], function(err) {
                if (err) {
                    return console.log(err.message);
                }

                console.log('Le todo ' + id + ' est modifié');
                res.redirect('/');
            });
        } else {
            console.log('Erreur ligne 77');
        }
    });
});

app.post('/test/post', urlencodedParser, function(req, res) {
    let name = 'Default todo';
    if (req.body.todo != '') {
        name = req.body.todo;
    }
    db.run(`INSERT INTO todo(name, done) VALUES(?, ?)`, [name, 0], function(err) {
        if (err) {
            return console.log(err.message);
        }
        console.log('Le todo marche');
    });

    res.redirect('/');

});

app.listen(port, hostname, () => {
    console.log('Serveur lancé sur http://' + hostname + ':' + port + '/');
});